package com.seleniumm;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByTag {
    public static void main(String[] args) {
        // Define driver path
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\webdriver\\chromedriver.exe");

        // Create an instance of driver
        WebDriver driver = new ChromeDriver();

        // Load the web page under test
        driver.get("file:///C:/Users/Administrator/eclipse-workspace/com.selenium/test.html");

        // Find element by tag name
        WebElement element = driver.findElement(By.tagName("input"));
        
        // Send keys to the element
        element.sendKeys("Some text here");

        Thread.sleep(3000);

        driver.quit();
    }
}
