package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ContactPage {
	private WebDriver driver;
	//Create Locators
	private By aboutLink=By.id("aboutLink");
	private By homeLink=By.id("homeLink");
	
	//name
	private By nameField = By.id("name");
	
	//email
	private By emailField = By.id("email");
	
	//messgae
	private By messageField = By.id("message");
	
	//
	private By submitButton = By.id("submitButton");
	
	
	//rmessageDiv
	private By rmessageDiv = By.id("rmessage");

	//constructor excects Webdriver as parameter
	 public ContactPage(WebDriver driver) {
		 System.out.println("Displaying Contact page...."+driver.getTitle());
		 this.driver = driver;
	 }
	 
	 //method to perform actions on above weElements
	 public AboutPage gotoAboutPage() {
		 WebElement aboutLinkElement= driver.findElement(aboutLink);
		 aboutLinkElement.click();
		 return new AboutPage(driver);
	 }

	 public HomePage gotoHomePage() {
		 WebElement homeLinkElement =driver.findElement(homeLink);
		 homeLinkElement.click();
		 return new HomePage(driver);
		 
	 }
	 
	 public void fillContactForm(String name, String email, String message) {
		 driver.findElement(nameField).sendKeys(name);
		 driver.findElement(emailField).sendKeys(email);
		 driver.findElement(messageField).sendKeys(message);
		 driver.findElement(submitButton).click();
	 }
	 
		public void checkSubmission() {
			System.out.println("Submitted Text:"+driver.findElement(rmessageDiv).getText());
		}
}


/*//subsribeForm
private By subsribeForm = By.id("subsribeForm");
//email
private By email = By.id("email");
//subscribeButton
private By subscribeButton = By.id("subscribeButton");
//acceptTerms
private By acceptTerms = By.id("acceptTerms");*/