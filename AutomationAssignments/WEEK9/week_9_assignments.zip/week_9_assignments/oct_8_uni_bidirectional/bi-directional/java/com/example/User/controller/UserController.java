package com.example.User.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.User.model.Profile;
import com.example.User.model.User;
import com.example.User.service.UserService;

@RestController
public class UserController {

    @Autowired
    private UserService uService;

    @PostMapping("/user")
    public User createUser(@RequestBody User user) {
        return uService.createUser(user);
    }

    @GetMapping("/user/{userid}")
    public User getUser(@PathVariable long userid) {
        return uService.getUser(userid);
    }

    // New endpoint to get Profile by User ID
    @GetMapping("/user/{userid}/profile")
    public Profile getProfileByUserId(@PathVariable long userid) {
        return uService.getProfileByUserId(userid);
    }
}
