package com.selenium.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MainTestApp {
	public static void main(String[] args) throws Exception {

		// Set the path for the ChromeDriver

		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver.exe");

		//create an instance of driver
		WebDriver driver=new ChromeDriver();
		//load web page under test
		driver.get("file:///C:\\Users\\Administrator\\eclipse-workspace\\Spring\\com.selenium.pom\\src\\main\\resources\\Home.html");// create homepage instance
		HomePage homePage = new HomePage(driver);

		// on homepage click aboutlink
		AboutPage aboutPage = homePage.gotoAboutPage();
		aboutPage.showMoreInfo();
		Thread.sleep(3000);
		aboutPage.validateShowMore();

		ContactPage contactPage = homePage.gotoContactPage();

		Thread.sleep(3000);

		aboutPage = contactPage.gotoAboutPage();
		// from above aboutlink goback to homepage
		aboutPage.gotoHomePage();
		Thread.sleep(3000);
		contactPage = aboutPage.gotoContactPage();
		Thread.sleep(3000);

		homePage = contactPage.gotoHomePage();
		Thread.sleep(3000);

		homePage.gotoContactPage();
		
		contactPage.fillContactForm("Maneesha", "maneesha@mailinator.com", "Messgae");
		Thread.sleep(3000);
		contactPage.checkSubmission();
		Thread.sleep(3000);
		driver.quit();
	}
}