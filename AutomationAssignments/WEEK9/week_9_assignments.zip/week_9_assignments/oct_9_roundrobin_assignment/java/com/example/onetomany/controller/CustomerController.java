package com.example.onetomany.controller;

import com.example.onetomany.model.Customer;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CustomerController {

    @GetMapping("/getObject")
    public Customer getLimitedObject(@RequestParam String name) {
        return Customer.getInstance(name);  
    }
}
