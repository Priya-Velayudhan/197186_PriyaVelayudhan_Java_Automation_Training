package com.mockitoegg;

public interface UserRepository {
User findById(Long id);
}
