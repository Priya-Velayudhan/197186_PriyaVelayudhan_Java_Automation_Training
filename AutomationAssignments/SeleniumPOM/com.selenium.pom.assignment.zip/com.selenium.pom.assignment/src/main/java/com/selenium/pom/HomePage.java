package com.selenium.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	private WebDriver driver;
	//Create Locators
	private By aboutLink=By.id("aboutLink");
	private By contactLink=By.id("contactLink");
	
	//name
	By nameField = By.id("name");
	
	//email
	By emailField = By.id("email");
	
	//messgae
	By messageField = By.id("message");
	
	//
public HomePage(WebDriver driver) {
		 System.out.println("Displaying home page....."+driver.getTitle());
		 this.driver = driver;
	 }
	 
	 //method to perform actions on above weElements
	 public AboutPage gotoAboutPage() {
		 WebElement aboutLinkElement= driver.findElement(aboutLink);
		 aboutLinkElement.click();
		 return new AboutPage(driver);
	 }

	 public ContactPage gotoContactPage() {
		 WebElement contactLinkElement =driver.findElement(contactLink);
		 contactLinkElement.click();
		 return new ContactPage(driver);
		 
	 }
}


/*//subsribeForm
private By subsribeForm = By.id("subsribeForm");
//email
private By email = By.id("email");
//subscribeButton
private By subscribeButton = By.id("subscribeButton");
//acceptTerms
private By acceptTerms = By.id("acceptTerms");*/
//constructor excects Webdriver as parameter
 
