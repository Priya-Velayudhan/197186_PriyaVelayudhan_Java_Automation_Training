package com.example1.demo2;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoRestController {
	
	public DemoRestController() {
		System.out.println("constructor DemoRestController()");
	}
	
	@GetMapping("/abcd")
    String met() {
    	System.out.println("---jjjjjjjjjj---------");
    	return "Hello World";
    }
	@GetMapping("/users")
	User getUser() {
		return new User(2,"Nivin","ABC");
	}

}
