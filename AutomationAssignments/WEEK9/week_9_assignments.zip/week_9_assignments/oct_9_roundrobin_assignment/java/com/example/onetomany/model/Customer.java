package com.example.onetomany.model;

public class Customer {
    private static final int MAX_INSTANCES = 3;
    private static final Customer[] instances = new Customer[MAX_INSTANCES];
    private static int instanceCount = 0;
    private static int currentIndex = 0;

    private String name; 
   
    private Customer(String name) {
        this.name = name;
    }

   
    public static Customer getInstance(String name) {
       
        if (instanceCount < MAX_INSTANCES) {
            instances[instanceCount] = new Customer(name);
            instanceCount++;
        }
        
      
        Customer instance = instances[currentIndex];
        currentIndex = (currentIndex + 1) % MAX_INSTANCES;  
        return instance;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "{name='" + name + "'}";
    }
}
